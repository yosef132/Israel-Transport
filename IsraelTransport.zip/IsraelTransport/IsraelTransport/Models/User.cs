﻿using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class User
    {
        [Key]
        public int UserID { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        public string Username { get; set; }

        [Required]
        public string Email { get; set; }

        [Required]
        public string Password { get; set; }

        [Required]
        public string Language { get; set; }

        [Required]
        public string Country { get; set; }

        [Required]
        public string City { get; set; }

        [Required]
        public int UserTypeID { get; set; }

        public string UserType { get; set; } // Admin or Client
    }
}
