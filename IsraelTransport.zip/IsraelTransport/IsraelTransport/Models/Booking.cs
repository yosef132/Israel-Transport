﻿using System;
using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class Booking
    {
        [Key]
        public int BookingID { get; set; }

        [Required]
        public int UserID { get; set; }

        [Required]
        public int VehicleID { get; set; }

        [Required]
        public string Status { get; set; } // 'Pending', 'Confirmed', 'Cancelled'

        [Required]
        public DateTime DepartureTime { get; set; }

        [Required]
        public int Passengers { get; set; }

        [Required]
        public string PickupAddress { get; set; }

        [Required]
        public string DropOffAddress { get; set; }

        [Required]
        public string FullName { get; set; }

        [Required]
        [EmailAddress]
        public string Email { get; set; }

        [Required]
        public string PhoneNumber { get; set; }

        public DateTime? StartTrailDate { get; set; }
        public DateTime? EndTrailDate { get; set; }

        // Instead of a list, now just a single stop as a string
        public string StopStation { get; set; } // Single stop

        public string Notes { get; set; }
    }
}
