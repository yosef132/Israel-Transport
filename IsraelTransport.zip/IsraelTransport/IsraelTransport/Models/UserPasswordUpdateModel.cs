﻿namespace IsraelTransport.Models
{
    public class UserPasswordUpdateModel
    {
        public string Password { get; set; }

    }
}
