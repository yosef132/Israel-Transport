﻿using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class Report
    {
        [Key]
        public int ReportID { get; set; }

        [Required]
        public int UserID { get; set; }

        [Required]
        public string Message { get; set; }

        public DateTime Timestamp { get; set; } = DateTime.Now;

        [Required]
        [EnumDataType(typeof(ReportStatus))]
        public string Status { get; set; } = ReportStatus.Pending.ToString();
    }

    public enum ReportStatus
    {
        Pending,
        Reviewed,
        Resolved
    }

}
