﻿using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class VehicleInfo
    {
        [Key]
        public int VehicleInfoID { get; set; }
        public string Make { get; set; }
        public string Model { get; set; }
        public int Year { get; set; }
        public int Km { get; set; }
        public string VehicleType { get; set; }
        public string CarPlateNumber { get; set; }
    }
}
