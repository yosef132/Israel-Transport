﻿using System;
using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class VehicleService
    {
        [Key]
        public int ServiceID { get; set; }

        [Required]
        public int VehicleID { get; set; }

        [Required]
        public string ServiceType { get; set; }

        [Required]
        public DateTime ServiceDate { get; set; }

        [Required]
        public int Km { get; set; }
    }
}
