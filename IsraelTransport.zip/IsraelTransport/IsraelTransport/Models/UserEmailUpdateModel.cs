﻿namespace IsraelTransport.Models
{
    public class UserEmailUpdateModel
    {
        public string Email { get; set; }

    }
}
