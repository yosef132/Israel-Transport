﻿using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class BookingType
    {
        [Key]
        public int BookingTypeID { get; set; }

        [Required]
        public string TypeName { get; set; }
    }
}
