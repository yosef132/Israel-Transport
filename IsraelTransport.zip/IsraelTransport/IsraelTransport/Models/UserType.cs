﻿using System.ComponentModel.DataAnnotations;

namespace IsraelTransport.Models
{
    public class UserType
    {
        [Key]
        public int UserTypeID { get; set; }

        [Required]
        [StringLength(50)]
        public string UserTypeName { get; set; } // Ensure the property name matches the database
    }
} // Properly closed class with this brace
