﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;

namespace IsraelTransport.Services
{
    public class ReportService
    {
        private readonly ReportRepository _repository;

        public ReportService(ReportRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<Report>> GetReportsAsync()
        {
            return await _repository.GetReportsAsync();
        }

        public async Task<Report> GetReportByIdAsync(int id)
        {
            return await _repository.GetReportByIdAsync(id);
        }

        public async Task<Report> CreateReportAsync(Report report)
        {
            return await _repository.CreateReportAsync(report);
        }

        public async Task<bool> DeleteReportAsync(int id)
        {
            return await _repository.DeleteReportAsync(id);
        }

        public async Task UpdateReportAsync(Report updatedReport)
        {
            await _repository.UpdateReportAsync(updatedReport);
        }
    }
}
