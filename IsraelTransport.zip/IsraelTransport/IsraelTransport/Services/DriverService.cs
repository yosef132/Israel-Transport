﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;

namespace IsraelTransport.Services
{
    public class DriverService
    {
        private readonly DriverRepository _repository;
        private readonly PasswordService _passwordService;

        public DriverService(DriverRepository repository, PasswordService passwordService)
        {
            _repository = repository;
            _passwordService = passwordService;

        }
        public async Task<string> HashPasswordAsync(string password)
        {
            return await _passwordService.HashPasswordAsync(password);
        }
        public async Task<IEnumerable<Driver>> GetDriversAsync()
        {
            return await _repository.GetDriversAsync();
        }

        public async Task<Driver> GetDriverByIdAsync(int id)
        {
            return await _repository.GetDriverByIdAsync(id);
        }

        public async Task<Driver> CreateDriverAsync(Driver driver)
        {
            return await _repository.CreateDriverAsync(driver);
        }

        public async Task<bool> UpdateDriverAsync(int id, Driver updatedDriver)
        {
            return await _repository.UpdateDriverAsync(id, updatedDriver);
        }

        public async Task<bool> DeleteDriverAsync(int id)
        {
            return await _repository.DeleteDriverAsync(id);
        }
    }
}
