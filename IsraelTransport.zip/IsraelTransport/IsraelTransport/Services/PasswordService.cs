﻿namespace IsraelTransport.Services
{
    public class PasswordService
    {
        public async Task<string> HashPasswordAsync(string password)
        {
            return await Task.Run(() => BCrypt.Net.BCrypt.HashPassword(password));
        }
    }
}
