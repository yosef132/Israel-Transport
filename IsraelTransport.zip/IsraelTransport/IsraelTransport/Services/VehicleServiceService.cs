﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Services
{
    public class VehicleServiceService
    {
        private readonly VehicleServiceRepository _vehicleServiceRepository;

        public VehicleServiceService(VehicleServiceRepository vehicleServiceRepository)
        {
            _vehicleServiceRepository = vehicleServiceRepository;
        }

        public async Task<IEnumerable<VehicleService>> GetAllVehicleServicesAsync()
        {
            return await _vehicleServiceRepository.GetVehicleServicesAsync();
        }

        public async Task<VehicleService> GetVehicleServiceByIdAsync(int id)
        {
            return await _vehicleServiceRepository.GetVehicleServiceByIdAsync(id);
        }

        public async Task<bool> UpdateVehicleServiceAsync(int id, VehicleService updatedService)
        {
            var existingService = await _vehicleServiceRepository.GetVehicleServiceByIdAsync(id);

            if (existingService == null)
            {
                return false;
            }

            // Update only the necessary fields
            existingService.ServiceType = updatedService.ServiceType ?? existingService.ServiceType;
            existingService.ServiceDate = updatedService.ServiceDate != default ? updatedService.ServiceDate : existingService.ServiceDate;
            existingService.Km = updatedService.Km > 0 ? updatedService.Km : existingService.Km;

            return await _vehicleServiceRepository.UpdateVehicleServiceAsync(existingService);
        }

        public async Task<bool> DeleteVehicleServiceAsync(int id)
        {
            return await _vehicleServiceRepository.DeleteVehicleServiceAsync(id);
        }

        public async Task<VehicleService> CreateVehicleServiceAsync(VehicleService service)
        {
            return await _vehicleServiceRepository.CreateVehicleServiceAsync(service);
        }
    }
}
