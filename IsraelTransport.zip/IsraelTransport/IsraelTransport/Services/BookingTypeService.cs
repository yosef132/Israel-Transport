﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;

namespace IsraelTransport.Services
{
    public class BookingTypeService
    {
        private readonly BookingTypeRepository _repository;

        public BookingTypeService(BookingTypeRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<BookingType>> GetBookingTypesAsync()
        {
            return await _repository.GetBookingTypesAsync();
        }

        public async Task<BookingType> GetBookingTypeByIdAsync(int id)
        {
            return await _repository.GetBookingTypeByIdAsync(id);
        }

        public async Task<BookingType> CreateBookingTypeAsync(BookingType bookingType)
        {
            return await _repository.CreateBookingTypeAsync(bookingType);
        }

        public async Task<bool> UpdateBookingTypeAsync(int id, BookingType bookingType)
        {
            return await _repository.UpdateBookingTypeAsync(id, bookingType);
        }

        public async Task<bool> DeleteBookingTypeAsync(int id)
        {
            return await _repository.DeleteBookingTypeAsync(id);
        }
    }
}
