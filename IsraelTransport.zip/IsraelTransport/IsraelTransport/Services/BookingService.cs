﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Services
{
    public class BookingService
    {
        private readonly BookingRepository _bookingRepository;

        public BookingService(BookingRepository bookingRepository)
        {
            _bookingRepository = bookingRepository;
        }

        public async Task<IEnumerable<Booking>> GetBookingsAsync()
        {
            return await _bookingRepository.GetBookingsAsync();
        }

        public async Task<Booking> GetBookingByIdAsync(int id)
        {
            return await _bookingRepository.GetBookingByIdAsync(id);
        }

        public async Task<Booking> CreateBookingAsync(Booking booking)
        {
            return await _bookingRepository.CreateBookingAsync(booking);
        }

        // Remove direct _context access and delegate to the repository
        public async Task UpdateBookingAsync(Booking existingBooking)
        {
            await _bookingRepository.UpdateBookingAsync(existingBooking);
        }

        public async Task<bool> DeleteBookingAsync(int id)
        {
            return await _bookingRepository.DeleteBookingAsync(id);
        }
    }
}
