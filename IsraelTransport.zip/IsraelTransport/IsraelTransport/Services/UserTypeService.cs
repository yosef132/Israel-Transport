﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Services
{
    public class UserTypeService
    {
        private readonly UserTypeRepository _repository;

        public UserTypeService(UserTypeRepository repository)
        {
            _repository = repository;
        }

        public async Task<IEnumerable<UserType>> GetUserTypesAsync()
        {
            return await _repository.GetUserTypesAsync();
        }

        public async Task<UserType> CreateUserTypeAsync(UserType userType)
        {
            return await _repository.CreateUserTypeAsync(userType);
        }

        public async Task<bool> UpdateUserTypeAsync(int id, UserType userType)
        {
            return await _repository.UpdateUserTypeAsync(id, userType);
        }

        public async Task<bool> DeleteUserTypeAsync(int id)
        {
            return await _repository.DeleteUserTypeAsync(id);
        }
    }
}
