﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;
using BCrypt.Net; // You need to install BCrypt.Net-Next NuGet package

namespace IsraelTransport.Services
{
    public class UserService
    {
        private readonly UserRepository _userRepository;

        public UserService(UserRepository userRepository)
        {
            _userRepository = userRepository;
        }

        public async Task<IEnumerable<User>> GetAllUsersAsync()
        {
            return await _userRepository.GetUsersAsync();
        }

        public async Task<User> GetUserByIdAsync(int userId)
        {
            return await _userRepository.GetUserByIdAsync(userId);
        }

        public async Task<User> GetUserByUsernameAsync(string username)
        {
            return await _userRepository.GetUserByUsernameAsync(username);
        }

        public async Task<User> CreateUserAsync(User user)
        {
            // Hash the user's password before saving
            user.Password = BCrypt.Net.BCrypt.HashPassword(user.Password);

            return await _userRepository.CreateUserAsync(user);
        }

        public async Task<bool> UpdateUserAsync(int userId, User updatedUser)
        {
            var existingUser = await _userRepository.GetUserByIdAsync(userId);

            if (existingUser == null)
            {
                return false;
            }

            // Check if the new username is already taken by another user
            if (!string.IsNullOrEmpty(updatedUser.Username) && updatedUser.Username != existingUser.Username)
            {
                var userWithSameUsername = await _userRepository.GetUserByUsernameAsync(updatedUser.Username);
                if (userWithSameUsername != null)
                {
                    throw new InvalidOperationException("Username is already taken by another user.");
                }
            }

            // Only hash the password if it is being updated
            if (!string.IsNullOrEmpty(updatedUser.Password))
            {
                updatedUser.Password = BCrypt.Net.BCrypt.HashPassword(updatedUser.Password);
            }

            // Update only fields that are provided
            existingUser.FullName = updatedUser.FullName ?? existingUser.FullName;
            existingUser.Username = updatedUser.Username ?? existingUser.Username;
            existingUser.Email = updatedUser.Email ?? existingUser.Email;
            existingUser.Password = updatedUser.Password ?? existingUser.Password;
            existingUser.Language = updatedUser.Language ?? existingUser.Language;
            existingUser.Country = updatedUser.Country ?? existingUser.Country;
            existingUser.City = updatedUser.City ?? existingUser.City;
            existingUser.UserTypeID = updatedUser.UserTypeID;
            existingUser.UserType = updatedUser.UserType;

            return await _userRepository.UpdateUserAsync(existingUser);
        }

        public async Task<bool> UpdateUserEmailAsync(int userId, string email)
        {
            var existingUser = await _userRepository.GetUserByIdAsync(userId);
            if (existingUser == null)
            {
                return false;
            }

            existingUser.Email = email;
            return await _userRepository.UpdateUserAsync(existingUser);
        }

        public async Task<bool> UpdateUserPasswordAsync(int userId, string password)
        {
            var existingUser = await _userRepository.GetUserByIdAsync(userId);
            if (existingUser == null)
            {
                return false;
            }

            // Hash the new password before saving
            existingUser.Password = BCrypt.Net.BCrypt.HashPassword(password);
            return await _userRepository.UpdateUserAsync(existingUser);
        }
        public async Task<bool> DeleteUserAsync(int userId)
        {
            return await _userRepository.DeleteUserAsync(userId);
        }
    }
}
