﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Services
{
    public class VehicleInfoService
    {
        private readonly VehicleInfoRepository _vehicleInfoRepository;

        public VehicleInfoService(VehicleInfoRepository vehicleInfoRepository)
        {
            _vehicleInfoRepository = vehicleInfoRepository;
        }

        public async Task<IEnumerable<VehicleInfo>> GetAllVehiclesAsync()
        {
            return await _vehicleInfoRepository.GetAllVehiclesAsync();
        }

        public async Task<VehicleInfo> GetVehicleByIdAsync(int id)
        {
            return await _vehicleInfoRepository.GetVehicleByIdAsync(id);
        }

        public async Task<VehicleInfo> CreateVehicleAsync(VehicleInfo vehicle)
        {
            return await _vehicleInfoRepository.CreateVehicleAsync(vehicle);
        }

        public async Task<bool> UpdateVehicleAsync(int id, VehicleInfo updatedVehicle)
        {
            var vehicle = await _vehicleInfoRepository.GetVehicleByIdAsync(id);
            if (vehicle == null) return false;

            vehicle.Make = updatedVehicle.Make ?? vehicle.Make;
            vehicle.Model = updatedVehicle.Model ?? vehicle.Model;
            vehicle.Year = updatedVehicle.Year;
            vehicle.Km = updatedVehicle.Km;
            vehicle.VehicleType = updatedVehicle.VehicleType ?? vehicle.VehicleType;
            vehicle.CarPlateNumber = updatedVehicle.CarPlateNumber ?? vehicle.CarPlateNumber;

            return await _vehicleInfoRepository.UpdateVehicleAsync(vehicle);
        }

        public async Task<bool> DeleteVehicleAsync(int id)
        {
            return await _vehicleInfoRepository.DeleteVehicleAsync(id);
        }
    }
}
