﻿using IsraelTransport.Models;
using IsraelTransport.Repositories;

public class TripService
{
    private readonly TripRepository _tripRepository;

    public TripService(TripRepository tripRepository)
    {
        _tripRepository = tripRepository;
    }

    public async Task<IEnumerable<Trip>> GetTripsAsync()
    {
        return await _tripRepository.GetTripsAsync();
    }

    public async Task<Trip> GetTripByIdAsync(int id)
    {
        return await _tripRepository.GetTripByIdAsync(id);
    }

    public async Task<Trip> CreateTripAsync(Trip trip)
    {
        // If no days are provided, set to open 24 hours for all 7 days
        if (trip.OpenHour.Count == 0 && trip.CloseHour.Count == 0)
        {
            trip.OpenHour = Enumerable.Repeat("00:00", 7).ToList();  // Open 24 hours
            trip.CloseHour = Enumerable.Repeat("23:59", 7).ToList(); // Close at the end of the day
        }
        else
        {
            if (trip.OpenHour.Count < 7)
            {
                int missingDays = 7 - trip.OpenHour.Count;
                trip.OpenHour.AddRange(Enumerable.Repeat("Closed", missingDays));
            }

            if (trip.CloseHour.Count < 7)
            {
                int missingDays = 7 - trip.CloseHour.Count;
                trip.CloseHour.AddRange(Enumerable.Repeat("Closed", missingDays));
            }
        }

        return await _tripRepository.CreateTripAsync(trip);
    }


    public async Task<bool> UpdateTripAsync(int id, Trip updatedTrip)
    {
        var existingTrip = await _tripRepository.GetTripByIdAsync(id);
        if (existingTrip == null)
        {
            return false;
        }

        // Update the trip name and type if provided
        existingTrip.TripName = updatedTrip.TripName ?? existingTrip.TripName;
        existingTrip.TripType = updatedTrip.TripType ?? existingTrip.TripType;

        // Handle OpenHour and CloseHour:
        // If no values are provided, set default 24-hour opening for all 7 days
        if (updatedTrip.OpenHour == null || updatedTrip.OpenHour.Count == 0)
        {
            existingTrip.OpenHour = new List<string> { "00:00", "00:00", "00:00", "00:00", "00:00", "00:00", "00:00" };
        }
        else
        {
            existingTrip.OpenHour = updatedTrip.OpenHour;
            if (existingTrip.OpenHour.Count < 7)
            {
                // Fill remaining days with 'Closed'
                for (int i = existingTrip.OpenHour.Count; i < 7; i++)
                {
                    existingTrip.OpenHour.Add("Closed");
                }
            }
        }

        if (updatedTrip.CloseHour == null || updatedTrip.CloseHour.Count == 0)
        {
            existingTrip.CloseHour = new List<string> { "23:59", "23:59", "23:59", "23:59", "23:59", "23:59", "23:59" };
        }
        else
        {
            existingTrip.CloseHour = updatedTrip.CloseHour;
            if (existingTrip.CloseHour.Count < 7)
            {
                // Fill remaining days with 'Closed'
                for (int i = existingTrip.CloseHour.Count; i < 7; i++)
                {
                    existingTrip.CloseHour.Add("Closed");
                }
            }
        }

        // Update the description if provided
        existingTrip.Description = updatedTrip.Description ?? existingTrip.Description;

        return await _tripRepository.UpdateTripAsync(existingTrip);
    }


    // Method to delete a single trip by ID
    public async Task<bool> DeleteTripAsync(int id)
    {
        return await _tripRepository.DeleteTripAsync(id);
    }

    public async Task<bool> DeleteAllTripsAsync()
    {
        return await _tripRepository.DeleteAllTripsAsync();
    }
}
