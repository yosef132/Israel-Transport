﻿using Microsoft.EntityFrameworkCore;
using IsraelTransport.Models;

namespace IsraelTransport.Data
{
    public class ApplicationDbContext : DbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }

        public DbSet<Booking> Bookings { get; set; }
        public DbSet<BookingType> BookingTypes { get; set; } // Add this line
        public DbSet<Driver> Drivers { get; set; } // Add Drivers DbSet
        public DbSet<Report> Reports { get; set; }
        public DbSet<Trip> Trips { get; set; }
        public DbSet<UserType> UserTypes { get; set; }
        public DbSet<User> Users { get; set; }
        public DbSet<VehicleService> VehicleServices { get; set; }
        public DbSet<VehicleInfo> VehicleInfo { get; set; }


    }
}
