﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserTypesController : ControllerBase
    {
        private readonly UserTypeService _service;

        public UserTypesController(UserTypeService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<IActionResult> GetAllUserTypes()
        {
            var userTypes = await _service.GetUserTypesAsync();
            return Ok(userTypes);
        }

        [HttpPost]
        public async Task<IActionResult> CreateUserType(UserType userType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdUserType = await _service.CreateUserTypeAsync(userType);
            return CreatedAtAction(nameof(GetAllUserTypes), new { id = createdUserType.UserTypeID }, createdUserType);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateUserType(int id, UserType userType)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var updated = await _service.UpdateUserTypeAsync(id, userType);
            if (!updated)
            {
                return NotFound();
            }

            return Ok(new { message = "User type updated successfully" });
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteUserType(int id)
        {
            var deleted = await _service.DeleteUserTypeAsync(id);
            if (!deleted)
            {
                return NotFound();
            }

            return Ok(new { message = "User type deleted successfully" });
        }
    }
}
