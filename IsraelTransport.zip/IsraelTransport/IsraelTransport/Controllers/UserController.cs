﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UserController : ControllerBase
    {
        private readonly UserService _userService;

        public UserController(UserService userService)
        {
            _userService = userService;
        }

        [HttpGet("GetAllUsers")]
        public async Task<IActionResult> GetAllUsers()
        {
            var users = await _userService.GetAllUsersAsync();
            return Ok(users);
        }

        [HttpGet("GetUserById/{userId}")]
        public async Task<IActionResult> GetUserById(int userId)
        {
            var user = await _userService.GetUserByIdAsync(userId);
            if (user == null)
                return NotFound();

            return Ok(user);
        }

        [HttpPost("CreateUser")]
        public async Task<IActionResult> CreateUser(User user)
        {
            await _userService.CreateUserAsync(user);
            return CreatedAtAction(nameof(GetUserById), new { userId = user.UserID }, user);
        }

        [HttpPut("{id}")]

        [HttpPatch("PatchUserEmail/{userID}")]
        public async Task<IActionResult> PatchUserEmail(int userID, [FromBody] UserEmailUpdateModel emailModel)
        {
            if (string.IsNullOrEmpty(emailModel.Email))
            {
                return BadRequest(new { error = "Email is required" });
            }

            var result = await _userService.UpdateUserEmailAsync(userID, emailModel.Email);
            if (result)
            {
                return Ok(new { message = "Email updated successfully" });
            }

            return NotFound(new { error = "User not found" });
        }
        [HttpPatch("PatchUserPassword/{userID}")]
        public async Task<IActionResult> PatchUserPassword(int userID, [FromBody] UserPasswordUpdateModel passwordModel)
        {
            if (string.IsNullOrEmpty(passwordModel.Password))
            {
                return BadRequest(new { error = "Password is required" });
            }

            var result = await _userService.UpdateUserPasswordAsync(userID, passwordModel.Password);
            if (result)
            {
                return Ok(new { message = "Password updated successfully" });
            }

            return NotFound(new { error = "User not found" });
        }

        [HttpPut("UpdateUser/{userID}")]
        public async Task<IActionResult> UpdateUser(int userID, [FromBody] User userModel)
        {
            var existingUser = await _userService.GetUserByIdAsync(userID);
            if (existingUser == null)
            {
                return NotFound(new { error = "User not found" });
            }

            try
            {
                var result = await _userService.UpdateUserAsync(userID, userModel);
                if (result)
                {
                    return Ok(new { message = "User updated successfully" });
                }

                return StatusCode(500, new { error = "An error occurred while updating the user" });
            }
            catch (InvalidOperationException ex)
            {
                return BadRequest(new { error = ex.Message });
            }
        }



        [HttpDelete("DeleteUser/{userId}")]
        public async Task<IActionResult> DeleteUser(int userId)
        {
            var result = await _userService.DeleteUserAsync(userId);
            if (!result)
                return NotFound();

            return NoContent();
        }
    }
}
