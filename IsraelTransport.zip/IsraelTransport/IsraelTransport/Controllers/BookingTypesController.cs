﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingTypesController : ControllerBase
    {
        private readonly BookingTypeService _service;

        public BookingTypesController(BookingTypeService service)
        {
            _service = service;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<BookingType>>> GetBookingTypes()
        {
            var bookingTypes = await _service.GetBookingTypesAsync();
            return Ok(bookingTypes);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<BookingType>> GetBookingType(int id)
        {
            var bookingType = await _service.GetBookingTypeByIdAsync(id);
            if (bookingType == null) return NotFound();
            return Ok(bookingType);
        }

        [HttpPost]
        public async Task<ActionResult<BookingType>> CreateBookingType(BookingType bookingType)
        {
            var newBookingType = await _service.CreateBookingTypeAsync(bookingType);
            return CreatedAtAction(nameof(GetBookingType), new { id = newBookingType.BookingTypeID }, newBookingType);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBookingType(int id, BookingType bookingType)
        {
            var result = await _service.UpdateBookingTypeAsync(id, bookingType);
            if (!result) return NotFound();
            return Ok("Booking Type updated successfully");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteBookingType(int id)
        {
            var result = await _service.DeleteBookingTypeAsync(id);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
