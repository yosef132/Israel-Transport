﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ReportsController : ControllerBase
    {
        private readonly ReportService _service;

        public ReportsController(ReportService service)
        {
            _service = service;
        }

        // GET: api/Reports
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Report>>> GetReports()
        {
            return Ok(await _service.GetReportsAsync());
        }

        // GET: api/Reports/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Report>> GetReport(int id)
        {
            var report = await _service.GetReportByIdAsync(id);
            if (report == null)
            {
                return NotFound();
            }
            return Ok(report);
        }

        // POST: api/Reports
        [HttpPost]
        public async Task<ActionResult<Report>> CreateReport(Report report)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var createdReport = await _service.CreateReportAsync(report);
            return CreatedAtAction(nameof(GetReport), new { id = createdReport.ReportID }, createdReport);
        }

        // DELETE: api/Reports/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteReport(int id)
        {
            var success = await _service.DeleteReportAsync(id);
            if (!success)
            {
                return NotFound();
            }
            return NoContent();
        }

        // PUT: api/Reports/5
        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateReport(int id, [FromBody] Report updatedReport)
        {
            var existingReport = await _service.GetReportByIdAsync(id);
            if (existingReport == null)
            {
                return NotFound();
            }

            existingReport.Status = updatedReport.Status;
            await _service.UpdateReportAsync(existingReport);
            return Ok("Report updated successfully");
        }
    }
}
