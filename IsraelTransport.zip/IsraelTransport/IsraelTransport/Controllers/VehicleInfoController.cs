﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleInfoController : ControllerBase
    {
        private readonly VehicleInfoService _vehicleInfoService;

        public VehicleInfoController(VehicleInfoService vehicleInfoService)
        {
            _vehicleInfoService = vehicleInfoService;
        }

        [HttpGet("GetAllVehicles")]
        public async Task<IActionResult> GetVehicles()
        {
            var vehicles = await _vehicleInfoService.GetAllVehiclesAsync();
            return Ok(vehicles);
        }

        [HttpGet("GetVehicle/{id}")]
        public async Task<IActionResult> GetVehicleById(int id)
        {
            var vehicle = await _vehicleInfoService.GetVehicleByIdAsync(id);
            if (vehicle == null)
                return NotFound();

            return Ok(vehicle);
        }

        [HttpPost("CreateVehicle")]
        public async Task<IActionResult> CreateVehicle(VehicleInfo vehicle)
        {
            await _vehicleInfoService.CreateVehicleAsync(vehicle);
            return CreatedAtAction(nameof(GetVehicleById), new { id = vehicle.VehicleInfoID }, vehicle);
        }

        [HttpPut("UpdateVehicle/{id}")]
        public async Task<IActionResult> UpdateVehicle(int id, [FromBody] VehicleInfo vehicleModel)
        {
            var result = await _vehicleInfoService.UpdateVehicleAsync(id, vehicleModel);
            if (!result)
            {
                return NotFound(new { error = "Vehicle not found" });
            }

            return Ok(new { message = "Vehicle updated successfully" });
        }

        [HttpDelete("DeleteVehicle/{id}")]
        public async Task<IActionResult> DeleteVehicle(int id)
        {
            var result = await _vehicleInfoService.DeleteVehicleAsync(id);
            if (!result)
            {
                return NotFound(new { error = "Vehicle not found" });
            }

            return NoContent();
        }
    }
}
