﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using IsraelTransport.Models;
using IsraelTransport.Services;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripsController : ControllerBase
    {
        private readonly TripService _tripService;

        public TripsController(TripService tripService)
        {
            _tripService = tripService;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Trip>>> GetTrips()
        {
            var trips = await _tripService.GetTripsAsync();
            return Ok(trips);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Trip>> GetTrip(int id)
        {
            var trip = await _tripService.GetTripByIdAsync(id);
            if (trip == null)
                return NotFound();
            return Ok(trip);
        }

        [HttpPost("create")]
        public async Task<ActionResult<Trip>> CreateTrip(Trip trip)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var newTrip = await _tripService.CreateTripAsync(trip);
            return CreatedAtAction(nameof(GetTrip), new { id = newTrip.TripID }, newTrip);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateTrip(int id, Trip updatedTrip)
        {
            if (!ModelState.IsValid)
                return BadRequest(ModelState);

            var success = await _tripService.UpdateTripAsync(id, updatedTrip);
            if (!success)
                return NotFound();

            return Ok("Trip updated successfully");
        }

        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteTrip(int id)
        {
            var success = await _tripService.DeleteTripAsync(id);
            if (!success)
                return NotFound();

            return NoContent();
        }

        [HttpDelete("DeleteAllTrips")]
        public async Task<IActionResult> DeleteAllTrips()
        {
            var result = await _tripService.DeleteAllTripsAsync();
            if (result)
            {
                return Ok("All trips deleted successfully.");
            }

            return StatusCode(500, "Error deleting all trips.");
        }

    }
}
