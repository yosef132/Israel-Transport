﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BookingsController : ControllerBase
    {
        private readonly BookingService _bookingService;

        public BookingsController(BookingService bookingService)
        {
            _bookingService = bookingService;
        }

        // GET: api/Bookings
        [HttpGet]
        public async Task<ActionResult<IEnumerable<Booking>>> GetBookings()
        {
            var bookings = await _bookingService.GetBookingsAsync();
            return Ok(bookings);
        }

        // GET: api/Bookings/5
        [HttpGet("{id}")]
        public async Task<ActionResult<Booking>> GetBooking(int id)
        {
            var booking = await _bookingService.GetBookingByIdAsync(id);
            if (booking == null) return NotFound();
            return Ok(booking);
        }

        // POST: api/Bookings/create
        [HttpPost("create")]
        public async Task<ActionResult<Booking>> CreateBooking(Booking booking)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var newBooking = await _bookingService.CreateBookingAsync(booking);
            return CreatedAtAction(nameof(GetBooking), new { id = newBooking.BookingID }, newBooking);
        }

        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateBooking(int id, [FromBody] Booking updatedBooking)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var existingBooking = await _bookingService.GetBookingByIdAsync(id);
            if (existingBooking == null)
            {
                return NotFound("Booking not found");
            }

            // Update only the fields that have been provided
            existingBooking.Status = updatedBooking.Status ?? existingBooking.Status;
            existingBooking.DepartureTime = updatedBooking.DepartureTime != DateTime.MinValue ? updatedBooking.DepartureTime : existingBooking.DepartureTime;
            existingBooking.Passengers = updatedBooking.Passengers != 0 ? updatedBooking.Passengers : existingBooking.Passengers;
            existingBooking.PickupAddress = !string.IsNullOrWhiteSpace(updatedBooking.PickupAddress) ? updatedBooking.PickupAddress : existingBooking.PickupAddress;
            existingBooking.DropOffAddress = !string.IsNullOrWhiteSpace(updatedBooking.DropOffAddress) ? updatedBooking.DropOffAddress : existingBooking.DropOffAddress;
            existingBooking.FullName = !string.IsNullOrWhiteSpace(updatedBooking.FullName) ? updatedBooking.FullName : existingBooking.FullName;
            existingBooking.Email = !string.IsNullOrWhiteSpace(updatedBooking.Email) ? updatedBooking.Email : existingBooking.Email;
            existingBooking.PhoneNumber = !string.IsNullOrWhiteSpace(updatedBooking.PhoneNumber) ? updatedBooking.PhoneNumber : existingBooking.PhoneNumber;
            existingBooking.StartTrailDate = updatedBooking.StartTrailDate ?? existingBooking.StartTrailDate;
            existingBooking.EndTrailDate = updatedBooking.EndTrailDate ?? existingBooking.EndTrailDate;
            existingBooking.StopStation = !string.IsNullOrWhiteSpace(updatedBooking.StopStation) ? updatedBooking.StopStation : existingBooking.StopStation;
            existingBooking.Notes = !string.IsNullOrWhiteSpace(updatedBooking.Notes) ? updatedBooking.Notes : existingBooking.Notes;

            await _bookingService.UpdateBookingAsync(existingBooking);

            return Ok("Booking updated successfully");
        }




        // DELETE: api/Bookings/delete/5
        [HttpDelete("delete/{id}")]
        public async Task<IActionResult> DeleteBooking(int id)
        {
            var result = await _bookingService.DeleteBookingAsync(id);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
