﻿using IsraelTransport.Models;
using IsraelTransport.Services;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging; // Add this to enable logging


namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class DriversController : ControllerBase
    {
        private readonly DriverService _service;
        private readonly ILogger<DriversController> _logger; // Inject logger

        public DriversController(DriverService service, ILogger<DriversController> logger)
        {
            _service = service;
            _logger = logger;
        }

        [HttpGet]
        public async Task<ActionResult<IEnumerable<Driver>>> GetDrivers()
        {
            var drivers = await _service.GetDriversAsync();
            return Ok(drivers);
        }

        [HttpGet("{id}")]
        public async Task<ActionResult<Driver>> GetDriver(int id)
        {
            var driver = await _service.GetDriverByIdAsync(id);
            if (driver == null) return NotFound();
            return Ok(driver);
        }

        [HttpPost]
        public async Task<ActionResult<Driver>> CreateDriver(Driver driver)
        {
            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            try
            {
                var newDriver = await _service.CreateDriverAsync(driver);
                return CreatedAtAction(nameof(GetDriver), new { id = newDriver.DriverID }, newDriver);
            }
            catch (Exception ex)
            {
                // Capture inner exception details if available
                var innerException = ex.InnerException != null ? ex.InnerException.Message : ex.Message;

                // Log the detailed error for debugging purposes
                _logger.LogError(ex, "An error occurred while creating a driver: {InnerException}", innerException);

                // Return detailed error message for debugging
                return StatusCode(500, new
                {
                    message = "An error occurred while processing your request.",
                    detailedError = innerException // Log the inner exception if it exists
                });
            }
        }



        [HttpPut("{id}")]
        public async Task<IActionResult> UpdateDriver(int id, [FromBody] Driver updatedDriver)
        {
            // Get the existing driver from the database
            var existingDriver = await _service.GetDriverByIdAsync(id);
            if (existingDriver == null)
            {
                return NotFound("Driver not found");
            }

            // Only update the fields that are provided in the request (JSON)
            existingDriver.FullName = !string.IsNullOrWhiteSpace(updatedDriver.FullName) ? updatedDriver.FullName : existingDriver.FullName;
            existingDriver.Username = !string.IsNullOrWhiteSpace(updatedDriver.Username) ? updatedDriver.Username : existingDriver.Username;
            existingDriver.Email = !string.IsNullOrWhiteSpace(updatedDriver.Email) ? updatedDriver.Email : existingDriver.Email;

            if (!string.IsNullOrWhiteSpace(updatedDriver.Password))
            {
                // Hash the new password if provided
                existingDriver.Password = await _service.HashPasswordAsync(updatedDriver.Password);
            }

            existingDriver.Language = !string.IsNullOrWhiteSpace(updatedDriver.Language) ? updatedDriver.Language : existingDriver.Language;
            existingDriver.Country = !string.IsNullOrWhiteSpace(updatedDriver.Country) ? updatedDriver.Country : existingDriver.Country;
            existingDriver.City = !string.IsNullOrWhiteSpace(updatedDriver.City) ? updatedDriver.City : existingDriver.City;
            existingDriver.DrivingLicense = !string.IsNullOrWhiteSpace(updatedDriver.DrivingLicense) ? updatedDriver.DrivingLicense : existingDriver.DrivingLicense;

            if (updatedDriver.DrivingLicenseExpiration != DateTime.MinValue)
            {
                existingDriver.DrivingLicenseExpiration = updatedDriver.DrivingLicenseExpiration;
            }

            // Save the updated driver back to the database
            await _service.UpdateDriverAsync(id, existingDriver);

            return Ok("Driver updated successfully");
        }





        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteDriver(int id)
        {
            var result = await _service.DeleteDriverAsync(id);
            if (!result) return NotFound();
            return NoContent();
        }
    }
}
