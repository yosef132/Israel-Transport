﻿using IsraelTransport.Models; // Make sure the model references are correct
using IsraelTransport.Services; // Reference the service layer for vehicle services
using Microsoft.AspNetCore.Mvc;
using System.Threading.Tasks;

namespace IsraelTransport.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class VehicleServiceController : ControllerBase
    {
        private readonly VehicleServiceService _vehicleServiceService;

        public VehicleServiceController(VehicleServiceService vehicleServiceService)
        {
            _vehicleServiceService = vehicleServiceService;
        }

        // Get all vehicle services
        [HttpGet("GetAllVehicleServices")]
        public async Task<IActionResult> GetVehicleServices()
        {
            var services = await _vehicleServiceService.GetAllVehicleServicesAsync();
            return Ok(services);
        }

        // Get a vehicle service by ID
        [HttpGet("GetVehicleService/{id}")]
        public async Task<IActionResult> GetVehicleServiceById(int id)
        {
            var service = await _vehicleServiceService.GetVehicleServiceByIdAsync(id);
            if (service == null)
            {
                return NotFound(new { error = "Vehicle service not found" });
            }

            return Ok(service);
        }

        // Create a new vehicle service
        [HttpPost("CreateVehicleService")]
        public async Task<IActionResult> CreateVehicleService([FromBody] VehicleService vehicleService)
        {
            if (vehicleService == null)
            {
                return BadRequest(new { error = "Invalid vehicle service data" });
            }

            await _vehicleServiceService.CreateVehicleServiceAsync(vehicleService);
            return CreatedAtAction(nameof(GetVehicleServiceById), new { id = vehicleService.ServiceID }, vehicleService);
        }

        // Update a vehicle service
        [HttpPut("UpdateVehicleService/{id}")]
        public async Task<IActionResult> UpdateVehicleService(int id, [FromBody] VehicleService updatedService)
        {
            if (updatedService == null)
            {
                return BadRequest(new { error = "Invalid service data" });
            }

            var result = await _vehicleServiceService.UpdateVehicleServiceAsync(id, updatedService);
            if (result)
            {
                return Ok(new { message = "Vehicle service updated successfully" });
            }

            return NotFound(new { error = "Vehicle service not found" });
        }

        // Delete a vehicle service by ID
        [HttpDelete("DeleteVehicleService/{id}")]
        public async Task<IActionResult> DeleteVehicleService(int id)
        {
            var deleted = await _vehicleServiceService.DeleteVehicleServiceAsync(id);
            if (!deleted)
            {
                return NotFound(new { error = "Vehicle service not found" });
            }

            return NoContent();
        }
    }
}
