using IsraelTransport.Data;
using IsraelTransport.Repositories;
using IsraelTransport.Services;
using Microsoft.EntityFrameworkCore;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();

// Add DbContext for SQL Server using the connection string from appsettings.json
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseSqlServer(builder.Configuration.GetConnectionString("DefaultConnection")));

// Register the repository and service for dependency injection
builder.Services.AddScoped<BookingRepository>();
builder.Services.AddScoped<BookingService>();

// Register BookingType repository and service
builder.Services.AddScoped<BookingTypeRepository>();
builder.Services.AddScoped<BookingTypeService>();

// Register Driver repository and service
builder.Services.AddScoped<DriverRepository>();
builder.Services.AddScoped<DriverService>();
builder.Services.AddScoped<PasswordService>();

// Register Report repository and service
builder.Services.AddScoped<ReportRepository>();   // Register Report Repository
builder.Services.AddScoped<ReportService>();      // Register Report Service

builder.Services.AddScoped<TripRepository>();
builder.Services.AddScoped<TripService>();

builder.Services.AddScoped<UserTypeRepository>();   // Register UserTypeRepository
builder.Services.AddScoped<UserTypeService>();

builder.Services.AddScoped<UserRepository>();
builder.Services.AddScoped<UserService>();

// Register VehicleInfo repository and service
builder.Services.AddScoped<VehicleInfoRepository>();   // Register VehicleInfo Repository
builder.Services.AddScoped<VehicleInfoService>();      // Register VehicleInfo Service


builder.Services.AddScoped<VehicleServiceRepository>();
builder.Services.AddScoped<VehicleServiceService>();
// Learn more about configuring Swagger/OpenAPI at https://aka.ms/aspnetcore/swashbuckle
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();

app.UseAuthorization();

app.MapControllers();

app.Run();
