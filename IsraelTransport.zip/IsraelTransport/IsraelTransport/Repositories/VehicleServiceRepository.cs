﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;

namespace IsraelTransport.Repositories
{
    public class VehicleServiceRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public VehicleServiceRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<VehicleService>> GetVehicleServicesAsync()
        {
            return await _dbContext.VehicleServices.ToListAsync();
        }

        public async Task<VehicleService> GetVehicleServiceByIdAsync(int serviceID)
        {
            return await _dbContext.VehicleServices.FindAsync(serviceID);
        }

        public async Task<VehicleService> CreateVehicleServiceAsync(VehicleService vehicleService)
        {
            _dbContext.VehicleServices.Add(vehicleService);
            await _dbContext.SaveChangesAsync();
            return vehicleService;
        }

        public async Task<bool> UpdateVehicleServiceAsync(VehicleService updatedService)
        {
            _dbContext.VehicleServices.Update(updatedService);
            return await _dbContext.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteVehicleServiceAsync(int serviceID)
        {
            var vehicleService = await _dbContext.VehicleServices.FindAsync(serviceID);
            if (vehicleService == null)
            {
                return false;
            }

            _dbContext.VehicleServices.Remove(vehicleService);
            return await _dbContext.SaveChangesAsync() > 0;
        }
    }
}
