﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;

namespace IsraelTransport.Repositories
{
    public class DriverRepository
    {
        private readonly ApplicationDbContext _context;

        public DriverRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Driver>> GetDriversAsync()
        {
            return await _context.Drivers.ToListAsync();
        }

        public async Task<Driver> GetDriverByIdAsync(int id)
        {
            return await _context.Drivers.FindAsync(id);
        }

        public async Task<Driver> CreateDriverAsync(Driver driver)
        {
            _context.Drivers.Add(driver);
            await _context.SaveChangesAsync();
            return driver;
        }

        public async Task<bool> UpdateDriverAsync(int id, Driver updatedDriver)
        {
            var existingDriver = await _context.Drivers.FindAsync(id);
            if (existingDriver == null) return false;

            existingDriver.FullName = updatedDriver.FullName;
            existingDriver.Username = updatedDriver.Username;
            existingDriver.Email = updatedDriver.Email;
            existingDriver.Password = updatedDriver.Password; // Ideally, hash this password
            existingDriver.Language = updatedDriver.Language;
            existingDriver.Country = updatedDriver.Country;
            existingDriver.City = updatedDriver.City;
            existingDriver.DrivingLicense = updatedDriver.DrivingLicense;
            existingDriver.DrivingLicenseExpiration = updatedDriver.DrivingLicenseExpiration;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteDriverAsync(int id)
        {
            var driver = await _context.Drivers.FindAsync(id);
            if (driver == null) return false;

            _context.Drivers.Remove(driver);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
