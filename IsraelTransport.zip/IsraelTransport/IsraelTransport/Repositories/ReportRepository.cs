﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;

namespace IsraelTransport.Repositories
{
    public class ReportRepository
    {
        private readonly ApplicationDbContext _context;

        public ReportRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<Report>> GetReportsAsync()
        {
            return await _context.Reports.ToListAsync();
        }

        public async Task<Report> GetReportByIdAsync(int id)
        {
            return await _context.Reports.FirstOrDefaultAsync(r => r.ReportID == id);
        }

        public async Task<Report> CreateReportAsync(Report report)
        {
            _context.Reports.Add(report);
            await _context.SaveChangesAsync();
            return report;
        }

        public async Task<bool> DeleteReportAsync(int id)
        {
            var report = await _context.Reports.FirstOrDefaultAsync(r => r.ReportID == id);
            if (report != null)
            {
                _context.Reports.Remove(report);
                await _context.SaveChangesAsync();
                return true;
            }
            return false;
        }

        public async Task UpdateReportAsync(Report updatedReport)
        {
            _context.Reports.Update(updatedReport);
            await _context.SaveChangesAsync();
        }
    }
}
