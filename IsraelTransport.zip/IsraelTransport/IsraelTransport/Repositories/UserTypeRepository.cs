﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Repositories
{
    public class UserTypeRepository
    {
        private readonly ApplicationDbContext _context;

        public UserTypeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<UserType>> GetUserTypesAsync()
        {
            return await _context.UserTypes.ToListAsync();
        }

        public async Task<UserType> CreateUserTypeAsync(UserType userType)
        {
            _context.UserTypes.Add(userType);
            await _context.SaveChangesAsync();
            return userType;
        }

        // Assuming this is the section where you're referencing the UserType class
        public async Task<bool> UpdateUserTypeAsync(int id, UserType updatedUserType)
        {
            var existingUserType = await _context.UserTypes.FindAsync(id);
            if (existingUserType == null)
            {
                return false;
            }

            // Replace 'UserType' with 'TypeName' in these lines
            existingUserType.UserTypeName = updatedUserType.UserTypeName;

            await _context.SaveChangesAsync();
            return true;
        }


        public async Task<bool> DeleteUserTypeAsync(int id)
        {
            var userType = await _context.UserTypes.FindAsync(id);
            if (userType == null)
            {
                return false;
            }

            _context.UserTypes.Remove(userType);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
