﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace IsraelTransport.Repositories
{
    public class VehicleInfoRepository
    {
        private readonly ApplicationDbContext _dbContext;

        public VehicleInfoRepository(ApplicationDbContext dbContext)
        {
            _dbContext = dbContext;
        }

        public async Task<IEnumerable<VehicleInfo>> GetAllVehiclesAsync()
        {
            return await _dbContext.VehicleInfo.ToListAsync();
        }

        public async Task<VehicleInfo> GetVehicleByIdAsync(int id)
        {
            return await _dbContext.VehicleInfo.FindAsync(id);
        }

        public async Task<VehicleInfo> CreateVehicleAsync(VehicleInfo vehicle)
        {
            _dbContext.VehicleInfo.Add(vehicle);
            await _dbContext.SaveChangesAsync();
            return vehicle;
        }

        public async Task<bool> UpdateVehicleAsync(VehicleInfo vehicle)
        {
            _dbContext.VehicleInfo.Update(vehicle);
            return await _dbContext.SaveChangesAsync() > 0;
        }

        public async Task<bool> DeleteVehicleAsync(int id)
        {
            var vehicle = await _dbContext.VehicleInfo.FindAsync(id);
            if (vehicle == null) return false;

            _dbContext.VehicleInfo.Remove(vehicle);
            return await _dbContext.SaveChangesAsync() > 0;
        }
    }
}
