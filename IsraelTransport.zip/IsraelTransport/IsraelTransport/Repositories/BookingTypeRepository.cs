﻿using IsraelTransport.Data;
using IsraelTransport.Models;
using Microsoft.EntityFrameworkCore;

namespace IsraelTransport.Repositories
{
    public class BookingTypeRepository
    {
        private readonly ApplicationDbContext _context;

        public BookingTypeRepository(ApplicationDbContext context)
        {
            _context = context;
        }

        public async Task<IEnumerable<BookingType>> GetBookingTypesAsync()
        {
            return await _context.BookingTypes.ToListAsync();
        }

        public async Task<BookingType> GetBookingTypeByIdAsync(int id)
        {
            return await _context.BookingTypes.FindAsync(id);
        }

        public async Task<BookingType> CreateBookingTypeAsync(BookingType bookingType)
        {
            _context.BookingTypes.Add(bookingType);
            await _context.SaveChangesAsync();
            return bookingType;
        }

        public async Task<bool> UpdateBookingTypeAsync(int id, BookingType bookingType)
        {
            var existingBookingType = await _context.BookingTypes.FindAsync(id);
            if (existingBookingType == null) return false;

            existingBookingType.TypeName = bookingType.TypeName;

            await _context.SaveChangesAsync();
            return true;
        }

        public async Task<bool> DeleteBookingTypeAsync(int id)
        {
            var bookingType = await _context.BookingTypes.FindAsync(id);
            if (bookingType == null) return false;

            _context.BookingTypes.Remove(bookingType);
            await _context.SaveChangesAsync();
            return true;
        }
    }
}
