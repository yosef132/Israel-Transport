import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart
from pymongo import MongoClient
from datetime import datetime, timedelta

def send_email(to_email, subject, body):
    from_email = "chatgptuser885@gmail.com"
    password = "ekil mkgp gkdf dvgg"
    display_name = "Bookings"

    msg = MIMEMultipart()
    msg['From'] = f"{display_name} <{from_email}>"
    msg['To'] = to_email
    msg['Subject'] = subject

    msg.attach(MIMEText(body, 'plain'))

    try:
        server = smtplib.SMTP('smtp.gmail.com', 587)
        server.starttls()
        server.login(from_email, password)
        text = msg.as_string()
        server.sendmail(from_email, to_email, text)
        server.quit()
        print(f"Email sent successfully to {to_email}")
    except Exception as e:
        print(f"Failed to send email to {to_email}: {e}")

def check_and_send_emails():
    print("Connecting to MongoDB...")
    client = MongoClient("mongodb+srv://chatgptuser885:MsZRk7CPMy3maMiK@israeltransport.ughamz3.mongodb.net/?retryWrites=true&w=majority&appName=israeltransport")  # Replace with your MongoDB connection string
    db = client["IsraelTransport"]
    bookings_collection = db["Bookings"]

    today = datetime.now()
    four_days_later = today + timedelta(days=4)

    print(f"Today's date: {today}")
    print(f"Date four days later: {four_days_later}")

    query = {"DepartureTime": {"$gte": today, "$lt": four_days_later}, "status": "Confirmed"}
    print(f"Query being used: {query}")
    booking_count = bookings_collection.count_documents(query)
    print(f"Found {booking_count} bookings to process.")

    bookings = bookings_collection.find(query)
    for booking in bookings:
        print(f"Processing booking: {booking}")  # Log the booking being processed
        subject = f"Reminder: Upcoming Trip {booking['BookingID']}"
        body = (f"Dear {booking['FullName']},\n\n"
                f"This is a reminder for your upcoming trip with Booking ID {booking['BookingID']} on "
                f"{booking['DepartureTime'].strftime('%Y-%m-%d')}.\n\n"
                f"Pickup Address: {booking['PickupAddress']}\n"
                f"Drop Off Address: {booking['DropOffAddress']}\n"
                f"Passengers: {booking['Passengers']}\n\n"
                f"Thank you!")
        send_email(booking['Email'], subject, body)

if __name__ == "__main__":
    print("Starting email notification script...")
    check_and_send_emails()
    print("Script finished.")
