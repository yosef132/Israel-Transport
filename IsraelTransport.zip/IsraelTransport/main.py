import pandas as pd
import matplotlib.pyplot as plt
from pymongo import MongoClient
import ttkbootstrap as ttk
import matplotlib.ticker as ticker

CONNECTION_STRING = "mongodb+srv://chatgptuser885:MsZRk7CPMy3maMiK@israeltransport.ughamz3.mongodb.net/?retryWrites=true&w=majority&appName=israeltransport"
DB_NAME = "IsraelTransport"

# Connect to MongoDB Atlas
client = MongoClient(CONNECTION_STRING)
db = client[DB_NAME]

# Function to fetch data from a collection
def fetch_data(collection_name):
    collection = db[collection_name]
    data = list(collection.find())
    return pd.DataFrame(data)

# Page 1: Booking Reports
def booking_reports():
    df_bookings = fetch_data("Bookings")

    bookings_status_table = df_bookings['status'].value_counts()
    print("Booking Status Report:")
    print(bookings_status_table)

    bookings_status_table.plot.pie(autopct=lambda p: '{:.0f}%'.format(p), figsize=(8, 8))
    plt.title("Booking Status Distribution")
    plt.ylabel("")  # Hide the y-label
    plt.show()

# Page 2: Driver Reports
def driver_reports():
    df_drivers = fetch_data("Drivers")

    drivers_city_table = df_drivers['city'].value_counts()
    print("Driver City Distribution:")
    print(drivers_city_table)

    # Example: Generate a bar chart of drivers by city with integer y-axis
    drivers_city_table.plot.bar(figsize=(10, 6))
    plt.title("Number of Drivers by City")
    plt.xlabel("City")
    plt.ylabel("Number of Drivers")

    ax = plt.gca()
    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    plt.show()

# Page 3: Vehicle Reports
def vehicle_reports():
    df_vehicles = fetch_data("Vehicles")

    # Example: Generate a table of vehicles by type
    vehicle_type_table = df_vehicles['vehicleType'].value_counts()
    print("Vehicle Type Distribution:")
    print(vehicle_type_table)

    # Example: Generate a bar chart of vehicle types with integer y-axis
    vehicle_type_table.plot.bar(figsize=(10, 6))
    plt.title("Vehicle Type Distribution")
    plt.xlabel("Vehicle Type")
    plt.ylabel("Number of Vehicles")

    ax = plt.gca()
    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    plt.show()

# Page 4: Report Status Reports
def report_status_reports():
    df_reports = fetch_data("Reports")

    # Example: Generate a table of reports by status
    report_status_table = df_reports['Status'].value_counts()
    print("Report Status Distribution:")
    print(report_status_table)

    # Example: Generate a pie chart of report statuses with integer percentages
    report_status_table.plot.pie(autopct=lambda p: '{:.0f}%'.format(p), figsize=(8, 8))
    plt.title("Report Status Distribution")
    plt.ylabel("")  # Hide the y-label
    plt.show()

# Page 5: User Reports
def user_reports():
    df_users = fetch_data("Users")

    # Example: Generate a table of users by country
    user_country_table = df_users['country'].value_counts()
    print("User Country Distribution:")
    print(user_country_table)

    # Example: Generate a bar chart of users by country with integer y-axis
    user_country_table.plot.bar(figsize=(10, 6))
    plt.title("Number of Users by Country")
    plt.xlabel("Country")
    plt.ylabel("Number of Users")

    ax = plt.gca()
    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    plt.show()

# Page 6: Bookings by Booking Type
def bookingtype_reports():
    df_bookingtypes = fetch_data("BookingTypes")

    # Generate a table of booking types
    bookings_by_type_table = df_bookingtypes['TypeName'].value_counts()
    print("Bookings by Booking Type:")
    print(bookings_by_type_table)

    # Generate a bar chart of bookings by booking type with integer y-axis
    bookings_by_type_table.plot.bar(figsize=(10, 6))
    plt.title("Bookings by Booking Type")
    plt.xlabel("Booking Type")
    plt.ylabel("Number of Bookings")

    ax = plt.gca()
    ax.yaxis.set_major_locator(ticker.MaxNLocator(integer=True))

    plt.show()



# Function to open the Booking Reports page
def open_booking_reports():
    booking_reports()  # Only display the matplotlib plot, no additional tkinter window

# Function to open the Driver Reports page
def open_driver_reports():
    driver_reports()  # Only display the matplotlib plot, no additional tkinter window

# Function to open the Vehicle Reports page
def open_vehicle_reports():
    vehicle_reports()  # Only display the matplotlib plot, no additional tkinter window

# Function to open the User Reports page
def open_user_reports():
    user_reports()  # Only display the matplotlib plot, no additional tkinter window

# Function to open the Report Status Reports page
def open_report_status_reports():
    report_status_reports()  # Only display the matplotlib plot, no additional tkinter window

# Function to open the Bookings by Booking Type page
def open_bookingtype_reports():
    bookingtype_reports()  # Only display the matplotlib plot, no additional tkinter window

# Set up the main window using ttkbootstrap
root = ttk.Window(themename="darkly")  # Use the 'darkly' theme for a modern dark look
root.title("Admin Dashboard")
root.geometry("800x600")

# Add a title label with rounded corners
title_label = ttk.Label(root, text="Admin Dashboard", style="primary.TLabel", font=("Helvetica", 24))
title_label.pack(pady=30)

# Create buttons for each report type with rounded corners, padding, and uniform width
button_frame = ttk.Frame(root)
button_frame.pack(pady=20)

button_width = 20  # Set a uniform width for all buttons

ttk.Button(button_frame, text="Booking Reports", command=open_booking_reports, bootstyle="success-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)
ttk.Button(button_frame, text="Driver Reports", command=open_driver_reports, bootstyle="info-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)
ttk.Button(button_frame, text="Vehicle Reports", command=open_vehicle_reports, bootstyle="warning-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)
ttk.Button(button_frame, text="User Reports", command=open_user_reports, bootstyle="danger-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)
ttk.Button(button_frame, text="Report Status Reports", command=open_report_status_reports, bootstyle="primary-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)
ttk.Button(button_frame, text="Bookings by Type", command=open_bookingtype_reports, bootstyle="secondary-outline", width=button_width).pack(pady=10, ipadx=10, ipady=5)

# Run the application
root.mainloop()
